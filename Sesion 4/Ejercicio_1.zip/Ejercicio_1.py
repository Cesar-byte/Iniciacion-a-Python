edad = int(input("Escribe tu edad: "))

if edad >= 18:
    print("Eres mayor de edad")
else:
    print("No eres mayor de edad") 
