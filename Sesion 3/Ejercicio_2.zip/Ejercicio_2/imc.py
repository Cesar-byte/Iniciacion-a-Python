import math

peso = float(input('Introduzca su peso (kg): '))

altura = float(input('Introduzca su altura (m): '))

imc=peso // (altura*altura)

imc = round(imc,2)

print(imc)